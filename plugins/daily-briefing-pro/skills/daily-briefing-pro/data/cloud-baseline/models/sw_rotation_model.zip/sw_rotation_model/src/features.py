"""Causal feature engineering for the industry rotation model.

Every feature on date t uses only bars up to and including t.  Forward
returns are built separately and are never fed back into the feature set.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

RET_WINDOWS = (1, 3, 5, 10, 20, 60)
MA_WINDOWS = (5, 10, 20, 60)
VOL_WINDOWS = (5, 10, 20, 60)
DD_WINDOWS = (20, 60)


def _by_code(frame: pd.DataFrame, column: str):
    return frame.groupby("code", sort=False)[column]


def _rolling_std(series: pd.Series, window: int) -> pd.Series:
    return series.rolling(window, min_periods=window).std()


def build_panel(px: pd.DataFrame, bench: pd.DataFrame,
                horizons: tuple[int, ...] = (1, 2, 3, 4, 5, 6),
                min_universe: int = 70, *,
                excess_mode: str = "demean",
                amt_log: bool = True,
                mom_accel_mode: str = "r5_r20",
                rs_mode: str = "market",
                csrank_mode: str = "pct") -> pd.DataFrame:
    """Return a long panel with causal features, forward returns and excesses."""
    df = px.copy()
    df["date"] = pd.to_datetime(df["date"])
    df["code"] = df["code"].astype(str)
    for col in ("open", "high", "low", "close", "volume", "amount"):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = (df.drop_duplicates(["code", "date"], keep="last")
            .sort_values(["code", "date"])
            .reset_index(drop=True))

    close = _by_code(df, "close")
    df["ret1"] = close.pct_change()
    for n in RET_WINDOWS:
        df[f"r{n}"] = close.pct_change(n)

    for n in MA_WINDOWS:
        ma = close.transform(lambda s, n=n: s.rolling(n, min_periods=n).mean())
        df[f"ma{n}"] = df["close"] / ma - 1.0

    for n in VOL_WINDOWS:
        df[f"vol{n}"] = _by_code(df, "ret1").transform(
            lambda s, n=n: _rolling_std(s, n))

    for n in DD_WINDOWS:
        peak = close.transform(lambda s, n=n: s.rolling(n, min_periods=n).max())
        df[f"dd{n}"] = df["close"] / peak - 1.0

    # Short-horizon momentum minus its pro-rata share of the 20-day move.
    if mom_accel_mode == "r3_r10":
        df["mom_accel"] = df["r3"] - 0.3 * df["r10"]
    elif mom_accel_mode == "r5_r10":
        df["mom_accel"] = df["r5"] - 0.5 * df["r10"]
    else:
        df["mom_accel"] = df["r5"] - 0.25 * df["r20"]

    # Turnover is log-scaled first so the 20-day z-score is not dominated by
    # board size; the level and the rank are both kept.
    log_amt = np.log1p(df["amount"].clip(lower=0)) if amt_log else df["amount"].clip(lower=0)
    amt = log_amt.groupby(df["code"], sort=False)
    amt_mean = amt.transform(lambda s: s.rolling(20, min_periods=20).mean())
    amt_std = amt.transform(lambda s: s.rolling(20, min_periods=20).std())
    df["amt_z"] = (log_amt - amt_mean) / amt_std.replace(0.0, np.nan)
    df["amt_chg5"] = log_amt.groupby(df["code"], sort=False).pct_change(5)

    # ------------------------------------------------------------------ #
    # CSI300 regime, aligned on the board trading calendar
    # ------------------------------------------------------------------ #
    b = bench.copy()
    b["date"] = pd.to_datetime(b["date"])
    b["close"] = pd.to_numeric(b["close"], errors="coerce")
    b = (b.dropna(subset=["date", "close"])
          .drop_duplicates("date", keep="last")
          .sort_values("date")
          .reset_index(drop=True))
    b_ret = b["close"].pct_change()
    b["csi_ma20"] = b["close"] / b["close"].rolling(20, min_periods=20).mean() - 1.0
    b["csi_vol20"] = _rolling_std(b_ret, 20)
    b_index = b.set_index("date")

    # ------------------------------------------------------------------ #
    # Cross-sectional state (equal-weight industry universe)
    # ------------------------------------------------------------------ #
    by_date = df.groupby("date", sort=False)
    for n in RET_WINDOWS:
        df[f"mkt_r{n}"] = by_date[f"r{n}"].transform("mean")
        if rs_mode == "csi":
            b_ret_n = b_index["close"].pct_change(n)
            df[f"rs{n}"] = df[f"r{n}"] - df["date"].map(b_ret_n)
        else:
            df[f"rs{n}"] = df[f"r{n}"] - df[f"mkt_r{n}"]
        ranked = by_date[f"r{n}"].rank(pct=True)
        df[f"csrank{n}"] = ranked - 0.5 if csrank_mode == "center" else ranked

    df["breadth1"] = by_date["r1"].transform(lambda s: (s > 0).mean())
    df["dispersion"] = by_date["r1"].transform("std")
    df["mkt_vol20"] = by_date["vol20"].transform("mean")
    df["amt_csrank"] = by_date["amt_z"].rank(pct=True)
    df["vol_csrank"] = by_date["vol20"].rank(pct=True)

    df = df.merge(b[["date", "csi_ma20", "csi_vol20"]], on="date", how="left")

    # ------------------------------------------------------------------ #
    # Forward labels: cumulative return over h sessions, demeaned across
    # the industry cross-section (relative rotation, not market beta).
    # ------------------------------------------------------------------ #
    for h in horizons:
        fwd = close.shift(-h) / df["close"] - 1.0
        df[f"fwd{h}"] = fwd
        if excess_mode == "raw":
            df[f"excess{h}"] = fwd
        elif excess_mode == "benchmark":
            bench_fwd = b_index["close"].shift(-h) / b_index["close"] - 1.0
            df[f"excess{h}"] = fwd - df["date"].map(bench_fwd)
        else:
            df[f"excess{h}"] = fwd - df.groupby("date", sort=False)[f"fwd{h}"].transform("mean")
        df[f"rank_fwd{h}"] = df.groupby("date", sort=False)[f"fwd{h}"].rank(pct=True)

    # min_universe is enforced by engine.latest_scorable_date at scoring time.
    # Keeping thinner early cross-sections preserves training history instead
    # of silently truncating the sample to the first day with 70 boards.
    return df.reset_index(drop=True)
