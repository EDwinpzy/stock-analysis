"""Industry rotation model package."""
