"""Fit / score / purged walk-forward backtest for Industry Rotation Core.

Protocol
--------
* expanding window starting at config.train_min_date
* the last `h` trading days before the cutoff are purged, so no training
  label's forward window can touch the prediction date
* features are standardised with training-set mean/std only
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import HistGradientBoostingRegressor

PKG = Path(__file__).resolve().parents[1]

TIE_KEY = "rs20"


def select_top(g: pd.DataFrame, k: int, tiebreak: str = TIE_KEY) -> pd.DataFrame:
    """Deterministic top-K selection under score ties.

    Tree ensembles emit leaf values, so ties are common. Without an explicit
    rule the selection would depend on row order, which makes the compounded
    equity path irreproducible. Ties break on 20-day relative strength, then
    code.
    """
    keys = [c for c in ("score", tiebreak, "code") if c in g.columns]
    ascending = [False if c in ("score", tiebreak) else True for c in keys]
    return g.sort_values(keys, ascending=ascending, kind="mergesort").head(k)


def load_config(path: Path | None = None) -> dict:
    """Load config and flatten the active universe's settings to the top level."""
    cfg = json.loads((path or PKG / "config.json").read_text(encoding="utf-8"))
    uni = cfg.get("universe")
    opts = cfg.get("universes", {}).get(uni)
    if uni and opts:
        for k, v in opts.items():
            if k not in ("label", "source"):
                cfg[k] = v
        cfg["universe_label"] = opts.get("label", uni)
    return cfg


def make_model(cfg: dict):
    m = cfg["model"]
    if m["type"] != "HistGradientBoostingRegressor":
        raise ValueError(f"unsupported model type: {m['type']}")
    return HistGradientBoostingRegressor(**m["params"])


def _trading_dates(panel: pd.DataFrame) -> pd.DatetimeIndex:
    return pd.DatetimeIndex(np.sort(panel["date"].unique()))


def _purge_mask(dates: pd.DatetimeIndex, cutoff: pd.Timestamp, h: int) -> pd.Timestamp:
    """Latest date considered safe as a training row for a cutoff date."""
    safe = dates[dates <= cutoff]
    if len(safe) <= h:
        return dates[0] - pd.Timedelta(days=1)
    return safe[-(h + 1)]


def training_slice(panel: pd.DataFrame, h: int, cutoff: pd.Timestamp, cfg: dict) -> pd.DataFrame:
    dates = _trading_dates(panel)
    last_ok = _purge_mask(dates, cutoff, h)
    m = panel[(panel["date"] >= pd.Timestamp(cfg["train_min_date"]))
              & (panel["date"] <= last_ok)]
    return m.dropna(subset=[f"excess{h}"])


def fit(panel: pd.DataFrame, h: int, cutoff: pd.Timestamp, cfg: dict) -> dict:
    features = [f for f in cfg["features"] if f in panel.columns]
    train = training_slice(panel, h, cutoff, cfg).dropna(subset=features)
    if train.empty:
        raise RuntimeError(f"no training rows for horizon {h} before {cutoff.date()}")
    X = train[features].to_numpy(dtype=float)
    mu = pd.Series(X.mean(axis=0), index=features)
    sd = pd.Series(X.std(axis=0, ddof=0), index=features).replace(0.0, 1.0)
    Xs = (X - mu.to_numpy()) / sd.to_numpy()
    y = train[f"excess{h}"].to_numpy(dtype=float)
    model = make_model(cfg)
    model.fit(Xs, y)
    return {
        "model": model,
        "features": features,
        "mu": mu,
        "sd": sd,
        "n_train": int(len(train)),
        "train_last": pd.Timestamp(train["date"].max()),
    }


def score_cross_section(panel: pd.DataFrame, fitted: dict, asof: pd.Timestamp) -> pd.DataFrame:
    feats = fitted["features"]
    cs = panel[panel["date"] == pd.Timestamp(asof)].dropna(subset=feats).copy()
    if cs.empty:
        raise RuntimeError(f"no complete cross-section on {pd.Timestamp(asof).date()}")
    X = cs[feats].to_numpy(dtype=float)
    Xs = (X - fitted["mu"].to_numpy()) / fitted["sd"].to_numpy()
    cs["score"] = fitted["model"].predict(Xs)
    cs = select_top(cs, len(cs))
    cs["rank"] = np.arange(1, len(cs) + 1, dtype=int)
    keep = [c for c in ("code", "name", "date", "close", "score", "rank", TIE_KEY)
            if c in cs.columns]
    return cs[keep].reset_index(drop=True)


def tie_report(scores: pd.DataFrame, k: int) -> dict:
    values = scores["score"]
    vc = values.value_counts()
    boundary = None
    if len(scores) >= k:
        value = float(values.iloc[k - 1])
        members = scores.loc[np.isclose(values, value), "name" if "name" in scores else "code"]
        boundary = {
            "value": value,
            "group_size": int(len(members)),
            "members": members.tolist(),
            "ambiguous": bool(len(members) > 1),
        }
    return {
        "n": int(len(scores)),
        "distinct_scores": int(values.nunique()),
        "largest_tie_group": int(vc.max()) if len(vc) else 0,
        "tied_rows": int(vc[vc > 1].sum()),
        "boundary": boundary,
    }


def latest_scorable_date(panel: pd.DataFrame, cfg: dict,
                         asof: pd.Timestamp | None = None) -> pd.Timestamp:
    feats = [f for f in cfg["features"] if f in panel.columns]
    m = panel if asof is None else panel[panel["date"] <= pd.Timestamp(asof)]
    counts = m.dropna(subset=feats).groupby("date")["code"].size()
    ok = counts[counts >= cfg["min_universe"]]
    if ok.empty:
        raise RuntimeError("no date has a complete-enough cross-section")
    return pd.Timestamp(ok.index.max())


def predict(panel: pd.DataFrame, cfg: dict, asof: pd.Timestamp | None = None) -> dict:
    asof = latest_scorable_date(panel, cfg, asof)
    out = {"asof": asof, "horizons": {}}
    for h in cfg["horizons"]:
        fitted = fit(panel, h, asof, cfg)
        cs = score_cross_section(panel, fitted, asof)
        out["horizons"][h] = {
            "scores": cs,
            "top": cs.head(cfg["top_k"]),
            "n_train": fitted["n_train"],
            "train_last": fitted["train_last"],
            "ties": tie_report(cs, cfg["top_k"]),
        }
    return out


# --------------------------------------------------------------------------- #
# Backtest (same protocol as the validation report)
# --------------------------------------------------------------------------- #
def _fold_starts(dates: pd.DatetimeIndex, start: pd.Timestamp, end: pd.Timestamp):
    test = dates[(dates >= start) & (dates <= end)]
    return sorted(pd.Series(test).dt.to_period("M").unique())


def backtest(panel: pd.DataFrame, cfg: dict, start: str, end: str) -> dict:
    return _backtest(panel, cfg, start, end, tiebreak=TIE_KEY)


def _backtest(panel: pd.DataFrame, cfg: dict, start: str, end: str,
              tiebreak: str = TIE_KEY) -> dict:
    start, end = pd.Timestamp(start), pd.Timestamp(end)
    dates = _trading_dates(panel)
    top_k, cost = cfg["top_k"], cfg["cost_round_trip"]
    results = {}
    for h in cfg["horizons"]:
        ret, exc, rk = f"fwd{h}", f"excess{h}", f"rank_fwd{h}"
        preds = []
        for per in _fold_starts(dates, start, end):
            t0, t1 = pd.Timestamp(per.start_time), min(pd.Timestamp(per.end_time), end)
            fitted = fit(panel, h, t0 - pd.Timedelta(days=1), cfg)
            te = panel[(panel["date"] >= t0) & (panel["date"] <= t1)].dropna(subset=fitted["features"])
            if te.empty:
                continue
            X = ((te[fitted["features"]] - fitted["mu"]) / fitted["sd"]).to_numpy()
            carry = ["date", "code", ret, exc, rk]
            if tiebreak in te.columns and tiebreak not in carry:
                carry.append(tiebreak)
            d = te[carry].copy()
            d["score"] = fitted["model"].predict(X)
            preds.append(d)
        if not preds:
            continue
        m = pd.concat(preds, ignore_index=True).dropna(subset=[ret])

        ics = m.groupby("date").apply(
            lambda g: stats.spearmanr(g["score"], g[ret]).statistic
            if g["score"].nunique() > 2 else np.nan, include_groups=False).dropna()
        per_date = m.groupby("date").apply(lambda g: pd.Series({
            "hit": len(set(select_top(g, min(top_k, len(g)), tiebreak)["code"])
                        & set(g.nlargest(min(top_k, len(g)), ret)["code"])) / min(top_k, len(g)),
            "exc": select_top(g, min(top_k, len(g)), tiebreak)[exc].mean(),
        }), include_groups=False)

        # Top-k portfolio, rebalanced every h sessions. Each holding period's
        # return is the equal-weight forward h-session return of the names
        # selected on the rebalance date. Compounding that h-session return on
        # every calendar row would count the same move h times.
        eq, prev, turns = 1.0, set(), []
        curve = []
        rebalance_dates = set(m["date"].sort_values().unique()[::h])
        for day, g in m.groupby("date"):
            if day not in rebalance_dates:
                continue
            g = g.dropna(subset=[ret])
            if g.empty:
                continue
            picked = select_top(g, min(top_k, len(g)), tiebreak)
            pick = picked["code"].tolist()
            turn = 1.0 if not prev else 1.0 - len(set(pick) & prev) / max(len(pick), 1)
            turns.append(turn)
            prev = set(pick)
            eq *= 1.0 + float(picked[ret].mean()) - cost * turn
            curve.append((pd.Timestamp(day).strftime("%Y-%m-%d"), eq))

        n_days = len(per_date)
        years = max((m["date"].max() - m["date"].min()).days / 365.25, 1e-9)
        ann = eq ** (1 / years) - 1 if eq > 0 else -1.0
        sharpe = float(per_date["exc"].mean() / per_date["exc"].std() * np.sqrt(252 / h)) \
            if per_date["exc"].std() > 0 else np.nan
        results[h] = {
            "rank_ic": float(ics.mean()),
            "ic_ir": float(ics.mean() / ics.std()) if ics.std() > 0 else np.nan,
            "ic_t": float(ics.mean() / ics.std() * np.sqrt(len(ics))) if ics.std() > 0 else np.nan,
            "topk_hit": float(per_date["hit"].mean()),
            "cum": float(eq - 1.0),
            "ann": float(ann),
            "sharpe": sharpe,
            "turnover": float(np.mean(turns)) if turns else np.nan,
            "days": int(n_days),
            "curve": curve,
        }
    return results
