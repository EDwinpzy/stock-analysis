"""Raw data access: industry daily bars + CSI300 benchmark.

Everything is cached under <pkg>/data so repeated runs are offline and
reproducible. Pass force=True to refetch.
"""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pandas as pd

PKG = Path(__file__).resolve().parents[1]
DATA = PKG / "data"
DATA.mkdir(parents=True, exist_ok=True)

SW_COLS = {"代码": "code", "日期": "date", "收盘": "close", "开盘": "open",
           "最高": "high", "最低": "low", "成交量": "volume", "成交额": "amount"}


def industry_list(force: bool = False) -> pd.DataFrame:
    p = DATA / "sw_l1_info.csv"
    if p.exists() and not force:
        return pd.read_csv(p, encoding="utf-8-sig", dtype={"code": str})
    import akshare as ak

    info = ak.sw_index_first_info().rename(columns={"行业代码": "code", "行业名称": "name"})
    info["code"] = info["code"].astype(str).str.replace(".SI", "", regex=False)
    out = info[["code", "name"]].copy()
    out.to_csv(p, index=False, encoding="utf-8-sig")
    return out


def industry_daily(codes: list[str], force: bool = False, retries: int = 4,
                   verbose: bool = True) -> pd.DataFrame:
    p = DATA / "sw_l1_daily.csv"
    if p.exists() and not force:
        px = pd.read_csv(p, encoding="utf-8-sig", dtype={"code": str})
        px["date"] = pd.to_datetime(px["date"])
        return px
    import akshare as ak

    frames = []
    for i, code in enumerate(codes, 1):
        for attempt in range(1, retries + 1):
            try:
                df = ak.index_hist_sw(symbol=code, period="day").rename(columns=SW_COLS)
                df["code"] = code
                frames.append(df[["code", "date", "close", "open", "high",
                                  "low", "volume", "amount"]])
                if verbose:
                    print(f"  [{i}/{len(codes)}] {code} rows={len(df)}")
                break
            except Exception:  # noqa: BLE001
                time.sleep(0.8 * attempt)
        time.sleep(0.35)
    px = pd.concat(frames, ignore_index=True)
    px["date"] = pd.to_datetime(px["date"])
    px = px.sort_values(["date", "code"]).reset_index(drop=True)
    px.to_csv(p, index=False, encoding="utf-8-sig")
    return px


def benchmark(force: bool = False) -> pd.DataFrame:
    p = DATA / "benchmark_csi300.csv"
    if p.exists() and not force:
        b = pd.read_csv(p, encoding="utf-8-sig")
        b["date"] = pd.to_datetime(b["date"])
        return b
    import akshare as ak

    last = None
    for fn_name in ("stock_zh_index_daily", "stock_zh_index_daily_tx"):
        for attempt in range(1, 4):
            try:
                df = getattr(ak, fn_name)(symbol="sh000300")
                df = df.rename(columns={"date": "date", "close": "close"})
                out = df[["date", "close"]].copy()
                out["date"] = pd.to_datetime(out["date"])
                out = out.sort_values("date").reset_index(drop=True)
                out.to_csv(p, index=False, encoding="utf-8-sig")
                return out
            except Exception as e:  # noqa: BLE001
                last = e
                time.sleep(1.2 * attempt)
    raise RuntimeError(f"CSI300 benchmark unavailable: {last}")


THS_DIR = DATA / "ths"
THS_COLS = {"日期": "date", "开盘价": "open", "最高价": "high", "最低价": "low",
            "收盘价": "close", "成交量": "volume", "成交额": "amount"}


def ths_industry_list(force: bool = False) -> pd.DataFrame:
    p = DATA / "ths_industry_info.csv"
    if p.exists() and not force:
        return pd.read_csv(p, encoding="utf-8-sig", dtype={"code": str})
    import akshare as ak

    nm = ak.stock_board_industry_name_ths()
    nm["code"] = nm["code"].astype(str)
    nm.to_csv(p, index=False, encoding="utf-8-sig")
    return nm


def ths_industry_daily(codes: list[str], names: list[str], force: bool = False,
                       retries: int = 4, verbose: bool = True,
                       workers: int = 4) -> pd.DataFrame:
    """Tonghuashun industry board history; resumable per board."""
    combined = DATA / "ths_industry_daily.csv"
    if combined.exists() and not force:
        px = pd.read_csv(combined, encoding="utf-8-sig", dtype={"code": str})
        px["date"] = pd.to_datetime(px["date"])
        return px.drop(columns=["name"], errors="ignore")
    import akshare as ak

    THS_DIR.mkdir(parents=True, exist_ok=True)
    todo = []
    for i, (code, name) in enumerate(zip(codes, names), 1):
        p = THS_DIR / f"{code}.csv"
        if p.exists() and p.stat().st_size > 1000 and not force:
            if verbose:
                print(f"  [{i}/{len(codes)}] {name} cached")
            continue
        todo.append((i, code, name, p))

    def fetch_one(item):
        i, code, name, p = item
        for attempt in range(1, retries + 1):
            try:
                df = ak.stock_board_industry_index_ths(symbol=name, start_date="20000101",
                                                       end_date="20991231")
                df = df.rename(columns=THS_COLS)
                df["code"], df["name"] = code, name
                df["date"] = pd.to_datetime(df["date"])
                df[["code", "name", "date", "close", "open", "high", "low",
                    "volume", "amount"]].to_csv(p, index=False, encoding="utf-8-sig")
                if verbose:
                    print(f"  [{i}/{len(codes)}] {name} rows={len(df)}")
                return True
            except Exception:  # noqa: BLE001
                time.sleep(1.5 * attempt)
        return False

    if todo:
        with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
            list(pool.map(fetch_one, todo))

    parts = [pd.read_csv(q, encoding="utf-8-sig", dtype={"code": str})
             for q in sorted(THS_DIR.glob("*.csv"))]
    px = pd.concat(parts, ignore_index=True)
    px["date"] = pd.to_datetime(px["date"])
    px = px.sort_values(["date", "code"]).reset_index(drop=True)
    px.to_csv(combined, index=False, encoding="utf-8-sig")
    return px.drop(columns=["name"], errors="ignore")


def load_all(force: bool = False, verbose: bool = True,
             universe: str = "sw") -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Return (industry_info, daily_panel, benchmark) for the requested universe."""
    bench = benchmark(force)
    if universe == "ths":
        info = ths_industry_list(force)
        px = ths_industry_daily(info["code"].tolist(), info["name"].tolist(),
                                force=force, verbose=verbose)
        return info, px, bench
    info = industry_list(force)
    px = industry_daily(info["code"].tolist(), force, verbose=verbose)
    return info, px, bench
