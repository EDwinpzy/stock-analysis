#!/usr/bin/env python
"""Industry rotation model - command line entry point.

Usage
-----
  python run.py fetch                       # fetch/cache raw data
  python run.py predict                     # fit on all history, rank the latest session
  python run.py predict --asof 2026-08-13   # reproducible as-of scoring
  python run.py backtest --start 2025-01-01 --end 2026-08-13

Outputs land in <pkg>/outputs/.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

PKG = Path(__file__).resolve().parent
sys.path.insert(0, str(PKG))

from src import data as data_mod  # noqa: E402
from src import engine  # noqa: E402
from src import features as feat_mod  # noqa: E402

OUT = PKG / "outputs"
OUT.mkdir(exist_ok=True)


def build_panel(cfg: dict, refresh: bool, verbose: bool = True) -> pd.DataFrame:
    info, px, bench = data_mod.load_all(force=refresh, verbose=verbose,
                                        universe=cfg.get("universe", "sw"))
    panel = feat_mod.build_panel(px, bench, horizons=tuple(range(1, 7)),
                                 min_universe=cfg["min_universe"])
    return panel.merge(info, on="code", how="left")


def cmd_fetch(cfg, args):
    _, px, bench = data_mod.load_all(force=args.force, verbose=True,
                                     universe=cfg.get("universe", "sw"))
    print(f"[data] industries={px['code'].nunique()} rows={len(px)} "
          f"{px['date'].min().date()}..{px['date'].max().date()}")
    print(f"[data] benchmark rows={len(bench)} last={bench['date'].max().date()}")


def cmd_predict(cfg, args):
    panel = build_panel(cfg, args.refresh)
    res = engine.predict(panel, cfg, pd.Timestamp(args.asof) if args.asof else None)
    a = res["asof"]
    print(f"\n=== {cfg.get('universe_label', cfg['name'])} rotation scores, "
          f"as of {a.date()} ===")

    merged = None
    for h, d in sorted(res["horizons"].items()):
        cs = d["scores"][["code", "name", "close", "score", "rank"]].rename(
            columns={"score": f"score_T{h}", "rank": f"rank_T{h}"})
        merged = cs if merged is None else merged.merge(
            cs[["code", f"score_T{h}", f"rank_T{h}"]], on="code", how="outer")
        print(f"\n--- T+{h}  (trained on {d['n_train']} rows up to "
              f"{pd.Timestamp(d['train_last']).date()}) ---")
        print(d["top"][["rank", "code", "name", "score"]].to_string(index=False))
        t = d["ties"]
        note = (f"  [ranking coarseness] {t['n']} industries -> "
                f"{t['distinct_scores']} distinct scores, largest tie group "
                f"{t['largest_tie_group']}")
        if t["boundary"] and t["boundary"]["ambiguous"]:
            note += (f"\n  [warning] the top-{cfg['top_k']} cut is tied: "
                     f"{t['boundary']['group_size']} industries share {t['boundary']['value']:.6f} "
                     f"({', '.join(t['boundary']['members'])}). "
                     f"Order here is a deterministic tie-break, not a conviction gap.")
        print(note)
        d["scores"][["code", "name", "date", "close", "score", "rank"]].to_csv(
            OUT / f"scores_T{h}_{a.date()}.csv", index=False, encoding="utf-8-sig")
        d["top"][["rank", "code", "name", "date", "close", "score"]].to_csv(
            OUT / f"top{cfg['top_k']}_T{h}_{a.date()}.csv", index=False, encoding="utf-8-sig")

    merged = merged.sort_values(f"rank_T{cfg['primary_horizon']}")
    merged.to_csv(OUT / f"all_scores_{a.date()}.csv", index=False, encoding="utf-8-sig")
    manifest = {
        "model": cfg["name"], "version": cfg["version"], "asof": str(a.date()),
        "horizons": list(cfg["horizons"]), "primary_horizon": cfg["primary_horizon"],
        "top_k": cfg["top_k"],
        "train_rows": {str(h): d["n_train"] for h, d in res["horizons"].items()},
        "train_last": {str(h): str(pd.Timestamp(d["train_last"]).date())
                       for h, d in res["horizons"].items()},
    }
    (OUT / f"predict_manifest_{a.date()}.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n[done] outputs -> {OUT}")
    return 0


def cmd_backtest(cfg, args):
    panel = build_panel(cfg, args.refresh)
    res = engine.backtest(panel, cfg, args.start, args.end)
    print(f"\n=== Purged walk-forward backtest {args.start} .. {args.end} "
          f"(cost {cfg['cost_round_trip']:.4f} round trip) ===")
    rows = []
    for h, m in sorted(res.items()):
        rows.append({"horizon": f"T+{h}", **{k: v for k, v in m.items() if k != "curve"}})
        pd.DataFrame(m["curve"], columns=["date", "equity"]).to_csv(
            OUT / f"equity_T{h}_{args.start}_{args.end}.csv", index=False, encoding="utf-8-sig")
    df = pd.DataFrame(rows)
    with pd.option_context("display.width", 220, "display.float_format", lambda v: f"{v:,.4f}"):
        print(df.to_string(index=False))
    df.to_csv(OUT / f"backtest_{args.start}_{args.end}.csv", index=False, encoding="utf-8-sig")
    return 0


def main() -> int:
    cfg = engine.load_config()
    ap = argparse.ArgumentParser(description="Industry rotation model")
    ap.add_argument("command", choices=["fetch", "predict", "backtest"])
    ap.add_argument("--asof", default=None, help="predict as of this date (YYYY-MM-DD)")
    ap.add_argument("--start", default=cfg["test_window"][0])
    ap.add_argument("--end", default=cfg["test_window"][1])
    ap.add_argument("--refresh", action="store_true", help="refetch raw data")
    ap.add_argument("--force", action="store_true", help="force full refetch")
    args = ap.parse_args()
    return {"fetch": cmd_fetch, "predict": cmd_predict, "backtest": cmd_backtest}[
        args.command](cfg, args) or 0


if __name__ == "__main__":
    raise SystemExit(main())
